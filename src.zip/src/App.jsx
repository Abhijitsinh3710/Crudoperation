
import Home from './Components/Home'
import './index.css'
function App() {

  return (
    <>
  
      <Home/>
    
     </>
  )
}

export default App
